<?php
include("maNav.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="row about">
<div class='col-lg-4 col-md4 col-sm-12 desc'>
<?php
$idProgram = $_POST["idProgram"];
$name = $_POST["Name"];
$hours = $_POST["hours"];
$type = $_POST["type"];
$price = $_POST["price"];
?>
<form action="" method="post" id = "form" style="left:5%; top:0% width:1wh">
<h4>
    Новая запись
</h4>
<input type="text" name="idProgram" placeholder="<?php
echo $idProgram;
?>"
class="form-control" id="">
<label for=""> Название программы обучения</label>
<input type="text" name="addName" placeholder="<?php
echo $name;
?>"
class="form-control" id="">
<label for=""> Кол-во часов</label>
<input type="text" name="addHours" placeholder="<?php
echo $hours;
?>" class="form-control" id="">
<label for=""> Вид программы обучения</label>
<input type="text" name="typeProgram" placeholder="<?php
echo $type;
?>" class="form-control" id="">
<label for=""> Стоимость </label>
<input type="number" name="addPrice" placeholder="<?php
echo $price;
?>" class="form-control" id="">
<button type="submit" name= "submit" class='btn btn-primary'>Добавить</button>
</form>
<?php
include("db.php");
if (ISSET($_POST['submit'])){
    $id = $_POST["idProgram"];
    $nameProgram = $_POST["addName"];
    $hoursProgram = $_POST["addHours"];
    $priceProgram = $_POST["addPrice"];
    $typeProgram = $_POST["typeProgram"];
    
    $sql = "UPDATE training_program SET Name_of_Program = '$nameProgram', Number_of_hours = '$hoursProgram', Price = '$priceProgram', Type_of_program = '$typeProgram'  WHERE  ID_Program = $id";
    var_dump($sql);
    $result = mysqli_query($db, $sql);
    if($result==TRUE){
        echo"Данные добавлены успешно!";
        echo"<script> document.location.href = 'manager.php'</script>";
    }
    else{
        echo"Ошибка";
        
    }
}
?>


</body>
</html>