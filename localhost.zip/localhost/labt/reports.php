<?php
include("maNav.php");
session_start();
include("db.php");


echo "<div class='row about'>
<div class='col-lg-4 col-md-4 col-sm-12'>
    <form action='' method='post'>
        <label for='rb1'>Выбор отчета:</label>
        <div class='form-check'>
    <input type='radio' class='form-check-input' value='1' id='rb1' name='rb1'>
    <label class='form-check-label' for='rb1'>
        Рейтинг программ обучения
    </label>
</div>
<div class='form-check'>
    <input type='radio' class='form-check-input' name='rb1' value='2' id='rb1'>
    <label for='rb1' class='form-check-label'>
        Рейтинг слушателей
    </label>
</div>
<button class='btn btn-primary' name='submit' type='submit'> Просмотр</button>
    </form>
</div>
</div>
";
?>
<?php
if(ISSET($_POST['submit'])){
    $n=$_POST['rb1'];
    if($n==1){
        $sum=0;
        $count=0;
        $sql = "SELECT training_program.Name_of_Program, training_program.Type_of_program, training_program.Price, COUNT(education.ID_Edu) AS kol, SUM(training_program.Price) AS summ FROM training_program INNER JOIN education ON training_program.ID_Program=education.ID_Program GROUP by training_program.Name_of_Program, training_program.Type_of_program, training_program.Price ORDER BY COUNT(education.ID_Edu) DESC";
        var_dump($sql);
        $result = mysqli_query($db,$sql);
        echo "<h4> Рейтинг программ обучения</h4>";
        echo"<table class='table table-bordered table-sm'>
        <tr class='table-primary'><th>Программа обучения</th><th>Вид программы</th>
        <th>Стоимость за ед.</th><th>Кол-во слушателей</th><th>На сумму</th>";
        while($myrow=mysqli_fetch_array($result)){
            $sum+=$myrow["summ"];
            $count+=$myrow['kol'];
            echo"<tr>";
            echo"<td>".$myrow['Name_of_Program']."</td>";
            echo"<td>".$myrow['Type_of_program']."</td>";
            echo"<td>".$myrow['Price']."</td>";
            echo"<td>".$myrow['kol']."</td>";
            echo"<td>".$myrow['summ']."</td>";
            echo"<tr>";
        }
            echo"<tr>";
            echo"<td></td><td><td><b>Итог:</b></td><td><b>$count</b></td><td><b>$sum</b></td>";
            echo"</tr>";
            echo "</table>";
        }
    
    }
?>

