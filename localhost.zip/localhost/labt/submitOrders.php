<?php
session_start();
include("db.php");
$idProgram = $_POST['idProgram'];
$idStud = $_SESSION['ID_Stud'];
$ordersDate = date("Y-m-d");
$status = 0;

$querty = "INSERT INTO `education` (ID_Stud,ID_Program,Data_of_z,Status) VALUES ('$idStud', '$idProgram','$ordersDate','$status')";
$result = mysqli_query($db, $querty);
if($result == TRUE){
    echo"Ваша заявка одобрена";
    echo "<script> document.location.href = 'orders.php'</script>";
}
else{
    echo("Ошибка");
}
?>
