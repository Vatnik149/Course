<?php
include("studNav.php");
?>
<?php
include("db.php");
$sql = "SELECT * FROM student WHERE ID_Stud = '$idUser'";
$result = mysqli_query($db,$sql);
$myrow = mysqli_fetch_array($result);

$userName = $myrow["User_name"];
$passw = $myrow["Passw"];
$lastName = $myrow["Lastname"];
$firstName = $myrow["Firstname"];
$fatherName = $myrow["Fathername"];
$birthDate = $myrow["Birth_Date"];
$edu = $myrow["Education"];
$tel = $myrow["Tel"];
$email = $myrow["Email"];

echo "
<div class='row about'>
    <div class='col-lg-4 col-md4 col-sm-12'>
        <img src='img/student.jpg' alt='' class='img-fluid'>
    </div>
    <div class='col-lg-4 col-md4 col-sm-12 desc'>
        <form action='#' method='POST' class='form-group'>
            <h4>Редактирование профиля</h4>
            <input type='text' placeholder='Логин/Email' class = 'form-control' name='userName' value='$userName'  id=''><br>
            <input type='password' placeholder='пароль' class = 'form-control' name='passw' value='$passw' id=''><br>
            <input type='text' placeholder='Фамилия'  class = 'form-control' name='lastName' value='$lastName' required id=''><br>
            <input type='text' placeholder='Имя'  class = 'form-control' name='firstName' value='$firstName' required id=''><br>
            <input type='text' placeholder='Отчество'  class = 'form-control' name='fatherName' value='$fatherName' required id=''><br>
            <input type='date' placeholder='Дата рождения'  class = 'form-control' name='birthDate' value='$birthDate'  id=''><br>

            <input type='text'  placeholder='Телефон' class = 'form-control' name='tel' value='$tel'  id=''><br>
            <input type='email' placeholder='Email'  class = 'form-control' name='email' value='$email'  id=''><br>
            <button type='submit'  class = 'form-control' name='submit' class='btn'>Сохранить</button>
        </form>
    </div>
</div>"

?>
<?php

    if(ISSET($_POST['submit']))
    {
        
    include("db.php");
    $idUser = $_SESSION['ID_Stud'];
    $userName = $_POST["userName"];
    $passw = $_POST["passw"];
    $lastName = $_POST["lastName"];
    $firstName = $_POST["firstName"];
    $fatherName = $_POST["fatherName"];
    $birthDate = $_POST["birthDate"];
    $tel = $_POST["tel"];
    $email = $_POST["email"];

    $sql = "UPDATE student SET User_name = '$userName', Passw = '$passw', Lastname = '$lastName', Firstname = '$firstName', Fathername = '$fatherName', Birth_Date = '$birthDate', tel = '$tel', Email = '$email' WHERE  ID_Stud = $idUser";
    $result = mysqli_query($db,$sql);
    if($result == TRUE){
        echo "Данные успешно сохранены";
        echo "<script> document.location.href = 'student.php'</script>";
    }
    else{
        echo "Ошибка";
    }
}   
?>
