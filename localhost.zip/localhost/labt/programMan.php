<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="row about">
<div class='col-lg-4 col-md4 col-sm-12 desc'>
    <form action="" method="post" id = "form" style="left:5%; top:0% width:1wh">
<h4>
    Новая запись
</h4>
<label for=""> Название программы обучения</label>
<input type="text" name="addName" placeholder="Название программы" class="form-control" id="">
<label for=""> Кол-во часов</label>
<input type="text" name="addHours" placeholder="0" class="form-control" id="">
<label for=""> Вид программы обучения</label>
<select name="typeProgram" value="Вид" id="" class="form-control">
    <option value="Повышение квалификации">Повышение квалификации</option>
    <option value="Переподготовка">Переподготовка</option>
</select>
<label for=""> Вид сертификации</label>
<select name="typeCertification" value="Вид" id="" class="form-control">
    <option value="Тестирование">Итоговое тестирование</option>
    <option value="Экзамен">Экзамен</option>
    <option value="Зачет">Зачет</option>
    <option value="ВКР">ВКР</option>
</select>
<label for=""> Вид документа об образовании </label>
<select name="typeDoc" value="Вид" id="" class="form-control">
    <option value="Удостоверение">Удостоверение</option>
    <option value="Сертификат">Сертификат</option>
</select>
<label for=""> Стоимость </label>
<input type="number" name="addPrice" placeholder="1000" class="form-control" id="">
<button type="submit" name= "submit" class='btn btn-primary'>Добавить</button>
</form>


</div>
<div class='col-lg-4 col-md4 col-sm-12 desc'>

<?php
include("db.php");
$sql = "SELECT * FROM training_program LIMIT $first, $kol";
$page = 1;
$kol = 3;
$first = 0;

if (isset($_GET['page'])){
    $page = $_GET['page'];
}
else{ $page = 1;}
$first = ($page*$kol)- $kol;


$sql = "SELECT COUNT(*) FROM training_program";
$result = mysqli_query($db,$sql);
$row = mysqli_fetch_row($result);

$total = $row[0];
$str_page = ceil($total / $kol);

for($i = 1; $i <=$str_page; $i++ ){
    echo "<a href = manager.php?page=".$i.">Страница ".$i."</a>"."|";
    
}


$sql = "SELECT * FROM training_program LIMIT $first, $kol";
$result = mysqli_query($db,$sql);
echo"<h4>Выбор программы обучения</h4>";
echo"<table class='table table-bordered table-sm'>
<tr class='table-primary'> <th>Номер</th><th>Название</th><th>Кол-во час</th><th>Вид программы</th><th>цена</th><th></th>";
while($myrow= mysqli_fetch_array($result)){
    echo"<tr>";
    echo "<td>".$myrow['ID_Program']."</td>";
    echo "<td>".$myrow['Name_of_Program']."</td>";
    echo "<td>".$myrow['Number_of_hours']."</td>";
    echo "<td>".$myrow['Type_of_program']."</td>";
    echo "<td>".$myrow['Price']."</td>";

    echo"<td><form method='post'>
    <button type='submit' class='btn btn-primary' formaction='submitUpd.php'>Изменить</button>
</td>";
echo"<input type='hidden' name='idProgram' value='".$myrow['ID_Program']."'>
<input type='hidden' name='Name' value='".$myrow['Name_of_Program']."'>
<input type='hidden' name='hours' value='".$myrow['Number_of_hours']."'>
<input type='hidden' name='type' value='".$myrow['Type_of_program']."'>
<input type='hidden' name='price' value='".$myrow['Price']."'>
</form>";
echo"</tr>";
}
echo"</table>";
?>
<?php
include("db.php");
if (ISSET($_POST['submit'])){
    $nameProgram = $_POST["addName"];
    $hours = $_POST["addHours"];
    $price = $_POST["addPrice"];
    $typeCertification = $_POST["typeCertification"];
    $typeDoc = $_POST["typeDoc"];
    $typeProgram = $_POST["typeProgram"];
    $sql = "INSERT INTO training_program (Name_of_Program, Number_of_hours, Price, Type_of_Certification, Type_of_Doc, Type_of_program) VALUES ('$nameProgram','$hours','$price','$typeCertification','$typeDoc','$typeProgram')";
    $result = mysqli_query($db, $sql);
    var_dump($result);
    if($result==TRUE){
        echo"Данные добавлены успешно!";
        echo"<script> document.location.href = 'manager.php'</script>";
    }
    else{
        echo"Ошибка";
    }
}
?>
</div>
</div>

</body>
</html>
