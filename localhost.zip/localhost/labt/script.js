function valid(){
    if(document.getElementById('password').value != document.getElementById('repass').value){
    alert('Пароли совпадают');
    return false;
}
}