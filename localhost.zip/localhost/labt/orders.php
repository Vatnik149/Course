<?php
session_start();
include("db.php");
include("studNav.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<div class='col-lg-4 col-md4 col-sm-12 desc'>
    
<?php
$idUser = $_SESSION['ID_Stud'];
$sql = "SELECT * FROM education WHERE ID_Stud=$idUser";
$result = mysqli_query($db,$sql);


echo"<h4>Мои заявки</h4>";
echo"<table class='table table-bordered table-sm'>
<tr class='table-primary'> <th>ID</th><th>Название</th><th>Дата заявки</th><th>Статус заявки</th><th>Начало обучения</th> <th>Дата окончания</th> <th>№ документа</th><th></th>";
while($myrow= mysqli_fetch_array($result)){
    echo"<tr>";
    echo "<td>".$myrow['ID_Program']."</td>";
    $idProg = $myrow['ID_Program'];
    $sqli = "SELECT * FROM training_program WHERE ID_Program=$idProg";
    $res = mysqli_query($db,$sqli);
    while($mytworow= mysqli_fetch_array($res)){
    echo "<td>".$mytworow['Name_of_Program']."</td>";
    }
    echo "<td>".$myrow['Data_of_z']."</td>";
    if($myrow['Status'] == 0){
        echo "<td>Рассматривается</td>";
    }
    else{
        echo "<td>Одобрен</td>";
    }
    echo "<td>".$myrow['Data_of_beginning']."</td>";
    echo "<td>".$myrow['Date_of_Close']."</td>";
    echo "<td></td>";
    echo"</tr>";
}


echo"</table>";

?>
</div>
</body>
</html>
