
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Login</title>
</head>
<body>
    <form  method = "POST">
        <input checked="" type="radio" name="action" id="signin" value="signin">
        <label for="signin">Вход</label>
        <input checked="" type="radio" name="action" id="signup" value="signup">
        <label for="signup">Регистрация</label>
        <input checked="" type="radio" name="action" id="reset" value="reset">
        <label for="reset">Reset</label>
        <div id="wrapper">
            <div id="arrow"></div>
            <input type="text" placeholder="Email" id="email" name="email">
            <input type="password" placeholder="Password" id="password" name="password">
            <input type="password" placeholder="Repass" id="repass" onkeyup="">
        </div>
        <button type="submit" name="submit">
            <span>
                Reset
                <br>
                Вход
                <br>
                Регистрация
            </span>
        </button>
    </form>
    <div id="hint">Click on the tubs</div>
    <script src="script.js"></script>
</body>
</html>
<?php
    if(ISSET($_POST['submit']))
    {
        $email = $_POST['email'];
        $passw = $_POST['password'];
     
        if(empty($email) or empty($passw)){
            exit("Вы ввели не всю информацию");
        }
     
        include("db.php");
        if($_POST['action'] =="signup"){
            $query = "SELECT * FROM `student` WHERE User_name='$email' OR Email= '$email'";
            $result = mysqli_query($db, $query);
            $myrow = mysqli_fetch_array($result);
            
            if(!empty($myrow['ID_Stud'])){
                exit("Извините, пользователь с такими email уже существует");
            }
            $query = "INSERT INTO  `student` (Email,User_name,Passw) VALUES ('$email', '$email','$passw')"; 
            //var_dump($query);
            $result = mysqli_query($db, $query);
            if($result == TRUE){
                echo "Вы успешно зарегистрированы. Теперь Вы можете авторизоваться и перейти в";
                $_SESSION['User_name'] =$email;
                $query="SELECT max(ID_Stud) AS ID_Stud From student";
                $result = mysqli_query($db, $query);
                $myrow = mysqli_fetch_array($result);
                $_SESSION['ID_Stud'] = $myrow['ID_Stud'];
                echo "<script> document.location.href = 'studNav.php'</script>";
            }
            else{
                echo("Ошибка регистрации");
            }
        }
        if($_POST['action'] =="signin"){
            $query = "SELECT * FROM `student` WHERE User_name='$email' OR Email= '$email'";
            $result = mysqli_query($db, $query);
            $myrow = mysqli_fetch_array($result);
            
            if(empty($myrow['User_name'])){
                exit("Извините, пользователь с таким логином/email не зарегистрирован");
            }
            else{
                if ($myrow['Passw']==$passw){
                    $_SESSION['User_name'] =$myrow['User_name'];
                    $_SESSION['ID_Stud'] =$myrow['ID_Stud'];
                    if($_POST['email'] == "manager"){
                        echo"<script> document.location.href = 'manager.php'</script>";
                    }
                    else{
                        echo"<script> document.location.href = 'studNav.php'</script>";
                    }
                }
                else{
                    exit("Пароль неверный");
                }
            }
            
        }
    }

?>


