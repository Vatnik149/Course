<?php

include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <title>Document</title>
</head>
<body>
<div class="row about">
<div class='col-lg-4 col-md4 col-sm-12 desc'>
    <form action="" method="post" id = "form" style="left:5%; top:0% width:1wh">
<h4>
    Фильтрация страницы
</h4>
<input type="checkbox" name="chb1" value="1" id="">По названию
<input type="text" name="searchName" placeholder="Название программы" class="form-control" id="">
<input type="checkbox" name="chb2" valur="2" id="">Вид
<select name="typeProgram" value="Вид" id="" class="form-control">
    <option value="Повышение квалификации">Повышение квалификации</option>
    <option value="Переподготовка">Переподготовка</option>
</select>
<input type="checkbox" name="chB3" value="3" id="">Макс. стоимость
<input type="number" name="serchPrice" placeholder="1000" class="form-control" id="">
<button type="submit" class='btn btn-primary'>Search</button>
</form>


</div>
<div class='col-lg-4 col-md4 col-sm-12 desc'>
    
<?php
$sql = "SELECT * FROM training_program";
$result = mysqli_query($db,$sql);
echo"<h4>Выбор программы обучения</h4>";
echo"<table class='table table-bordered table-sm'>
<tr class='table-primary'> <th>Номер</th><th>Название</th><th>Кол-во час</th><th>Вид программы</th><th>цена</th><th></th>";
while($myrow= mysqli_fetch_array($result)){
    echo"<tr>";
    echo "<td>".$myrow['ID_Program']."</td>";
    echo "<td>".$myrow['Name_of_Program']."</td>";
    echo "<td>".$myrow['Number_of_hours']."</td>";
    echo "<td>".$myrow['Type_of_program']."</td>";
    echo "<td>".$myrow['Price']."</td>";

    echo"<td><form method='post'>
    <button type='submit' class='btn btn-primary' formaction='submitOrders.php'>Записаться</button>
</td>";
echo"<input type='hidden' name='idProgram' value='".$myrow['ID_Program']."'></form>";
echo"</tr>";
}
echo"</table>";
?>
</div>
</div>
</body>
</html>
