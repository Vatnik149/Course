-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 08 2022 г., 21:17
-- Версия сервера: 8.0.24
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `jobdb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `education`
--

CREATE TABLE `education` (
  `ID_Edu` int NOT NULL,
  `ID_Stud` int NOT NULL,
  `ID_Program` int NOT NULL,
  `Data_of_z` date DEFAULT NULL,
  `Date_of_begining` date DEFAULT NULL,
  `Date_of_Closing` date DEFAULT NULL,
  `Payment` double DEFAULT NULL,
  `N_Doc` int DEFAULT NULL,
  `Status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `education`
--

INSERT INTO `education` (`ID_Edu`, `ID_Stud`, `ID_Program`, `Data_of_z`, `Date_of_begining`, `Date_of_Closing`, `Payment`, `N_Doc`, `Status`) VALUES
(1, 1, 1, '2021-12-18', NULL, NULL, NULL, NULL, 2),
(2, 21, 1, '2022-02-03', NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `student`
--

CREATE TABLE `student` (
  `ID_Stud` int NOT NULL,
  `Lastname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Firstname` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Fathername` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Birth_Date` date DEFAULT NULL,
  `Education` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Tel` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `User_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Passw` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `student`
--

INSERT INTO `student` (`ID_Stud`, `Lastname`, `Firstname`, `Fathername`, `Birth_Date`, `Education`, `Tel`, `Email`, `User_name`, `Passw`) VALUES
(1, 'Архипов', 'Кирилл', 'Романович', '2002-02-02', NULL, '89654323213', 'ghghgh@mail.ru', 'ghghgh@mail.ru', 'qwerty123'),
(20, NULL, NULL, NULL, NULL, NULL, NULL, 'manager', 'manager', '1111'),
(21, 'Заика', 'Дмитрий', NULL, NULL, NULL, NULL, 'kautdi@gmail.com', 'kautdi@gmail.com', '1111');

-- --------------------------------------------------------

--
-- Структура таблицы `training_program`
--

CREATE TABLE `training_program` (
  `ID_Program` int NOT NULL,
  `Name_of_Program` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Number_of_hours` int DEFAULT '72',
  `Price` double DEFAULT NULL,
  `Type_of_Certification` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'тестирование',
  `Type_of_Doc` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'удостоверение',
  `Type_of_program` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'повышение квалификации'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `training_program`
--

INSERT INTO `training_program` (`ID_Program`, `Name_of_Program`, `Number_of_hours`, `Price`, `Type_of_Certification`, `Type_of_Doc`, `Type_of_program`) VALUES
(1, 'Анализ данных', 72, 2100, 'тестирование', 'удостоверение', 'повышение квалификации'),
(2, 'Машинное обучение и искусственный интеллект', 120, 8500, 'тестирование', 'удостоверение', 'повышение квалификации'),
(3, 'Пользователь ПК', 72, 1200, 'тестирование', 'удостоверение', 'повышение квалификации'),
(4, 'Экономика и бухучет', 520, 11000, 'тестирование', 'удостоверение', 'переподготовка'),
(5, 'Веб-дизайн и разработка', 144, 5200, 'тестирование', 'удостоверение', 'повышение квалификации'),
(6, 'Новая программа', 72, 1000, 'Экзамен', 'Сертификат', 'Переподготовка'),
(7, 'Информационные системы и технологии', 72, 1000, 'Тестирование', 'Удостоверение', 'Переподготовка'),
(8, 'qqq', 1000, 1000, 'Тестирование', 'Удостоверение', 'Повышение квалификации'),
(9, 'dffds', 72, 1000, 'Экзамен', 'Сертификат', 'Переподготовка'),
(10, 'Прикладная информатика', 72, 1000, 'Зачет', 'Сертификат', 'Переподготовка');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`ID_Edu`),
  ADD KEY `ID_Stud` (`ID_Stud`),
  ADD KEY `ID_Program` (`ID_Program`);

--
-- Индексы таблицы `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID_Stud`);

--
-- Индексы таблицы `training_program`
--
ALTER TABLE `training_program`
  ADD PRIMARY KEY (`ID_Program`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `education`
--
ALTER TABLE `education`
  MODIFY `ID_Edu` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `student`
--
ALTER TABLE `student`
  MODIFY `ID_Stud` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `training_program`
--
ALTER TABLE `training_program`
  MODIFY `ID_Program` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `education`
--
ALTER TABLE `education`
  ADD CONSTRAINT `education_ibfk_1` FOREIGN KEY (`ID_Stud`) REFERENCES `student` (`ID_Stud`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `education_ibfk_2` FOREIGN KEY (`ID_Program`) REFERENCES `training_program` (`ID_Program`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
